/* Coverity Scan model */

void dummy(void)
{
}
