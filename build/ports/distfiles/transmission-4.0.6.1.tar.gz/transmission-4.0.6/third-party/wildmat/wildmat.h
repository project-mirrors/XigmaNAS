#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int
DoMatch (const char * text, const char * p);

#ifdef __cplusplus
}
#endif
