# GOT BETTER ICONS? PULL REQUESTS WELCOMED

## [Material Icons](https://github.com/google/material-design-icons/)

[Material icons overview @ material.io](https://m3.material.io/styles/icons/overview)

license: Apache-2.0 license

- horizontal-rule.svg
- pause-circle-active.svg
- pause-circle-idle.svg
- play-circle-active.svg
- play-circle-idle.svg
- router.svg

## [Feather Icons](https://github.com/feathericons/feather)

license: MIT

- index.html nav button svg
- chevron-down.svg
- chevron-up.svg

## Inspector 'i' icon

- Created in OmniGraffle by [https://github.com/dareiff]

## Bootstrap Icons

[https://github.com/twbs/icons]
[https://icons.getbootstrap.com/icons/]
license: MIT

- lock-fill.svg
- magnet.svg

## SVG Repo

https://www.svgrepo.com/
license: CC0

- up-and-down-arrows.svg

## Custom Icons

license: MIT

- logo.png
- toolbar-close.png
- toolbar-folder.png
- toolbar-info.png
- toolbar-pause.png
- toolbar-start.png
- modern-tortoise.png
- modern-tortoise-blue.png
